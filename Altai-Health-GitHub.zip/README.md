# Altai Health

Two projects are included:

- `altai-public/dist/`: public company website, including HTML, CSS, JavaScript, and illustrations. This dist folder is the editable static site and must remain in the repository.
- `altai-health/`: React/Vinext care dashboard with patient check-ins, AI chat, care summaries, and review priorities. See its README for setup.

## Upload to GitHub

Create an empty repository (private recommended for the dashboard prototype). Choose **Add file > Upload files**, then drag the contents of this folder into it. If GitHub limits the number of files in one upload, upload the two project folders in separate batches. Include the root README and .gitignore. For large batches, GitHub Desktop or Git is preferable.

The accompanying ZIP is a transport copy. Extract it before uploading if you want browsable source code; uploading the ZIP alone does not unpack the project on GitHub.

## What is excluded

Installed dependencies, caches, generated dashboard output, Git history, local tool state, and existing Sites project IDs are excluded. Dependencies can be reinstalled from package.json and pnpm-lock.yaml. The blank .env.example is safe configuration guidance; production credentials are managed separately and are not included.

Uploading this code does not change the live Sites websites, transfer their server secrets, or automatically deploy either project. The dashboard is a fictional-data prototype, not validated for clinical use.

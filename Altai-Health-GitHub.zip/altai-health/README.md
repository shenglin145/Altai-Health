# Altai Health AI

Private demonstration of post-surgical patient check-ins and care-team coordination, informed by the supplied Techstars deck, supplemental application and demo video.

## Working prototype
- Four fictional patient recovery journeys.
- Patient check-ins update the care-team view in the current browser session.
- Physical, emotional and social concerns, review filters, editable routing and team assignment.
- Server-side Responses API integration for conversational check-ins and handoff summaries.
- Explicit missing-key, error and loading states. No fabricated AI replies.

## Live AI configuration
Set OPENROUTER_API_KEY as a Sites secret and OPENROUTER_MODEL (default openai/gpt-4.1-mini), then redeploy. OpenRouter is preferred when configured. OPENAI_API_KEY and OPENAI_MODEL remain an optional direct-provider alternative. No credentials belong in client code or Git. Check-in text is sent to the configured model provider only when an AI action is invoked. OpenRouter routes it to the chosen model provider. Direct OpenAI requests use store:false; neither path is a claim of zero retention or HIPAA compliance. API behavior follows https://developers.openai.com/api/docs/guides/text.

Credentials are configured only in hosted secrets, never in the source. The public company website has no model credential.

## Local development
Install dependencies with pnpm install, then run pnpm dev. Run pnpm build for production and node node_modules/typescript/bin/tsc --noEmit for type checks. The bundled Sites Windows package-manager helper failed, so the equivalent node scripts/run-framework.mjs build command was used. The original npm lockfile was retained locally in .sites-runtime/original-package-lock.json; pnpm is the available package manager in this environment.

## Limits
This is not the existing MVP shown in the supplied video and does not connect to its backend. State resets on refresh. No real patient records, SMS, phone calling, EHR integration, automatic escalation, PHQ-9 assessment, resource enrollment, wound assessment or clinical decision support are connected. Care routing is a local demo action, not a notification. Clinical deployment requires separately implemented and validated storage, role authorization, audit trails, consent, integration and escalation workflows. Use fictional information only.

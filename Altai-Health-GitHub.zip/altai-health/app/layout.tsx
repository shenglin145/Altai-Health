import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Altai Health AI | Connected Recovery",
  description: "Patient check-ins and care-team coordination for recovery after hospital discharge.",
  other: {
    "codex-preview": "development",
  },
  icons: {
    icon: "/favicon.svg",
    shortcut: "/favicon.svg",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en">
      <body className="antialiased">{children}</body>
    </html>
  );
}


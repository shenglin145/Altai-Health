export const levels = ['High','Moderate','Low','Unassessed'] as const;
export type PriorityLevel = typeof levels[number];
export type Priority = {level:PriorityLevel;source:'Example'|'AI suggestion'|'Manual override'|'Unassessed';reason:string;evidence:string[];unknowns:string[];suggested?:PriorityLevel};
export const freshPriority=():Priority=>({level:'Unassessed',source:'Unassessed',reason:'New information requires review. No risk level has been assigned.',evidence:[],unknowns:['Clinical review pending']});
export function rankPriority(level:PriorityLevel){return {High:0,Unassessed:1,Moderate:2,Low:3}[level]}
export function validatePriority(value:unknown,report:string):Omit<Priority,'source'> {
 if(!value||typeof value!=='object')throw new Error('Invalid priority response');
 const v=value as Record<string,unknown>;
 if(!levels.includes(v.level as PriorityLevel)||typeof v.reason!=='string'||!v.reason.trim()||v.reason.length>1200||!Array.isArray(v.evidence)||v.evidence.length>5||!v.evidence.every(e=>typeof e==='string'&&e.length>0&&e.length<500&&report.includes(e))||!Array.isArray(v.unknowns)||v.unknowns.length>8||!v.unknowns.every(e=>typeof e==='string'&&e.length>0&&e.length<300))throw new Error('Invalid or unsupported priority evidence');
 if(v.level!=='Unassessed'&&v.evidence.length===0)throw new Error('Risk suggestions require patient evidence');
 return {level:v.level as PriorityLevel,reason:v.reason,evidence:v.evidence as string[],unknowns:v.unknowns as string[]};
}
